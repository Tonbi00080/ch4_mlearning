# spam-database-ja

これは私のメールアドレスに送られてきたスパムメールをまとめたものです。
機械学習の練習に使うように公開します。

スパムデータベースにメッセージを登録したい時は、<spam.hosii@gmail.com>までメールを転送してください。

- mailto:spam.hosii@gmail.com

なお、更新は不定期です。
